//Uso de Inerface, heranca, colecoes, funcoes lambdas, objetos literais, Json
//definicao de interface ara a estrutura do pagamento
interface Pagamento{
    valor:  number;
    pagar():void;
    exibirValor?():void; // opcional
}

//classe abstrata base para os pagamentos
abstract class PagamentoBase implements Pagamento {
    constructor(public valor:number) {}
    
    //metodo abstrato - vou implementar nas subclasses
    abstract pagar():void;

    exibirValor(): void{
    console.log(`Valor do pagamento: R$${this.valor.toFixed(2)}`);
    }
}

//subclasse para pagamento com cartao
class PagamentoCartao extends PagamentoBase{
    constructor(valor:number, public bandeira:string){
        super(valor);
    }

    //sobrescrita do metodo abstrato
    pagar():void{
        console.log(`Pagamento de R$${this.valor.toFixed(2)}realizado com cartao ${this.bandeira}.`);
    }
}

//subclasse para pagamento com boleto
class PagamentoBoleto extends PagamentoBase{
    constructor(valor:number, public codigoBarras:string){
        super(valor);
    }

    //sbrescrita do metodo abstrato
    pagar():void{
        console.log(`Pagamento de R$${this.valor.toFixed(2)} realizado com boleto. Código de Barras:${this.codigoBarras}`);
    }
}

//uso de JSON
const pagamentosJson=[
    {tipo:"cartao", valor:250.0, bandeira:"Visa"},
    {tipo:"boleto", valor:450.0, codigoBarras: "123456789"},
    {tipo:"cartao", valor:890.0, bandeira:"Elo"}
];

//Funcao de conversao JSon - instancias de classe
function criarPagamento(json:any):Pagamento{
    if (json.tipo==="cartao"){
        return new PagamentoCartao(json.valor, json.bandeira);
    }else if (json.tipo==="boleto"){
        return new PagamentoBoleto(json.valor, json.codigoBarras);
    }throw new Error("Tipo de pagamento desconhecido");
}

//Exemplo com objetivos literais
const pagamentosRapidos: Pagamento[]=[{valor:150.0, pagar:()=> console.log("Pagamento rapido de R$150,00 efetuado!")}, 
    {valor:200.0, pagar:()=> console.log("Pagamento rapido de R$200,00 efetuado!")},];

//funcao para proccessar os pgtos (cartao e boleto)
function proccessarPagamento(pagamento: Pagamento):void{
    pagamento.exibirValor?.();

    if (pagamento instanceof PagamentoCartao){
        console.log(`Detalhes: Pagamento com cartao bandeira ${pagamento.bandeira}.`)
    }else if (pagamento instanceof PagamentoBoleto){
        console.log(`Detalhes: Pagamento com Boleto (código de barras: ${pagamento.codigoBarras})`);
    }
    pagamento.pagar();
}

//criar as instancias de classe
const pagamento1 = new PagamentoCartao(500, "Visa");
const pagamento2 = new PagamentoBoleto(800,"12345667899");

//processar pagamentos
proccessarPagamento(pagamento1);
proccessarPagamento(pagamento2);

//processar pagtos rápidos (objetos literais)
pagamentosRapidos.forEach(proccessarPagamento);

//transformar o Json em instancias de classe e processar
pagamentosJson.map(criarPagamento).forEach(proccessarPagamento);
