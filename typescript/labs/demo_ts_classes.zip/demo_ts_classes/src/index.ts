//definicao de interface ara a estrutura do pagamento
interface Pagamento{
    valor:  number;
    pagar():void;
    exibirValor?():void; // opcional
}

//classe abstrata base para os pagamentos
abstract class PagamentoBase implements Pagamento {
    constructor(public valor:number) {}
    
    //metodo abstrato - vou implementar nas subclasses
    abstract pagar():void;

    exibirValor(): void{
    console.log(`Valor do pagamento: R$${this.valor.toFixed(2)}`);
    }
}

//subclasse para pagamento com cartao
class PagamentoCartao extends PagamentoBase{
    constructor(valor:number, public bandeira:string){
        super(valor);
    }

    //sobrescrita do metodo abstrato
    pagar():void{
        console.log(`Pagamento de R$${this.valor.toFixed(2)}realizado com cartao ${this.bandeira}.`);
    }
}

//subclasse para pagamento com boleto
class PagamentoBoleto extends PagamentoBase{
    constructor(valor:number, public codigoBarras:string){
        super(valor);
    }

    //sbrescrita do metodo abstrato
    pagar():void{
        console.log(`Pagamento de R$${this.valor.toFixed(2)} realizado com boleto. Código de Barras:${this.codigoBarras}`);
    }
}

//Exemplo com objetivos literais
const pagamentosRapidos: Pagamento[]=[{valor:150.0, pagar:()=> console.log("Pagamento rapido de R$150,00 efetuado!")}, 
    {valor:200.0, pagar:()=> console.log("Pagamento rapido de R$200,00 efetuado!")},]
    