//exemplo para modulos, promise, tratamento de exceção, função assíncrona
//importamos a funcao dividir que esta em modulo
import { dividir } from "./operacoes";

//Função assincrona que simula uma operação com atraso
async function calcularDivisao(a:number, b:number) {
    try{
    console.log("Vamos iniciar o cálculo");
    const resultado=await dividirComAtraso(a,b);
    console.log(`Resultado:${resultado}`);
    } catch(error){
        console.error(`Erro:${(error as Error).message}`);
    }
}

//funcao que simula o atraso
//foi feito tbm o tratamwnto de exceção
function dividirComAtraso(a:number, b:number):Promise<number>
{
    return new Promise((resolve,reject)=> {
        setTimeout(()=>{
            try{
                resolve(dividir(a,b));
            }catch(error){
                reject(error);
            }
        }, 1000); // este é o atraso de 1 segundo para a função 
    });
}

//vamos chamar a funcao para que seja lançada a exceção - erro da divisao por 0
calcularDivisao(10,0);