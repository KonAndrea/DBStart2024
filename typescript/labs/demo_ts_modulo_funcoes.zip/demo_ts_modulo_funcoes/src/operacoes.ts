//modulo que exporta uma função simples para divisao
//e um exemplo que lança uma exceção caso ocorra o problema da divisão por zero
export function dividir(a:number, b:number):number{
    if(b===0){
        throw new Error("Não é possível dividir por zero");
    }
    return a/b;
}