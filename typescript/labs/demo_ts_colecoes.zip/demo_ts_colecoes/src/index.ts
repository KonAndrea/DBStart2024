//definicao de interface para uma tarefa
interface Tarefa{
    id: number;
    descricao: string;
    concluida: boolean;
}

//incializar um array para as tarefas
const tarefas: Tarefa[]=[];

//Funcao para adicinar tarefas
function adicionarTarefa(descricao:string):void{
    const novaTarefa: Tarefa={
        id: tarefas.length+1,
        descricao,
        concluida: false
    };
    tarefas.push(novaTarefa);
    console.log(`Tarefa adiconada: ${novaTarefa.descricao}`);
}

//Funcao para listar as tarefas
function listarTarefas():void{
    console.log("Lista de Tarefas");
    tarefas.forEach((tarefa)=> {
        console.log(`${tarefa.id}.[${tarefa.concluida ? "X" : " "}]${tarefa.descricao}`);
    });
}

//Funcao para definir tarefa como concluida
function concluirTarefa(id:number):void{
    const tarefa=tarefas.find((t)=> t.id===id);
    if (tarefa){
        tarefa.concluida=true;
        console.log(`Tarefa concluída: ${tarefa.descricao}`);
        }else{
            console.log("Tarefa não encontrada");
        }
}

//Funcao para retornar as descricoes usando MAP
function listarDescricoesTarefas(): string[]{
    return tarefas.map((tarefa)=> tarefa.descricao);
}

//testando as funções
adicionarTarefa("Estudar TypeScript");
adicionarTarefa("Passear com os cachorros");
listarTarefas();
concluirTarefa(1);
listarTarefas();

//testando o map
const descricoes = listarDescricoesTarefas();
console.log("Descrições de Tarefas:", descricoes);